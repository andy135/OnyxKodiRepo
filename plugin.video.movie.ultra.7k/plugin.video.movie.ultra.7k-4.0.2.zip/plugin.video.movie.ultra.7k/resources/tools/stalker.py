# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# Version 0.0.1 (12.11.2014)
#   !!! Intentar NO compartir este archivo !!!
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------
import json
from __main__ import *
from pprint import pprint
fle=playlists+'warronch.db';
q='aHR0cHM6Ly9kLmRvaXB0di5jb20vc3RhbGtlcl9wb3J0YWwvc2VydmVyL2xvYWQucGhw';
q='c3RhbGtlcl9wb3J0YWwvc2VydmVyL2xvYWQucGhw'
p='stalker_portal/server/load.php'
#http://www.iptvlinks.com/2014/10/android-iptv-set-top-box-emulator.html
#http://iptv.asdnet.dn.ua/stalker_portal/c/index.html
#https://d.doiptv.com/stalker_portal/server/load.php
#http://portal.iptvprivateserver.tv/stalker_portal/server/load.php
q='aHR0cDovL3BvcnRhbC5pcHR2cHJpdmF0ZXNlcnZlci50di9zdGFsa2VyX3BvcnRhbC9zZXJ2ZXIvbG9hZC5waHA='

q='http://83.242.110.16:88/';q=q+p;q=q.encode('base64')
q='http://stalker.stbemu.com/';q=q+p;q=q.encode('base64')
#q='http://194.12.227.140/';q=q+p;q=q.encode('base64')
#q='http://magstreamer.hopto.me/';q='http://37.59.13.76:2709/';q=q+p;q=q.encode('base64')#http://37.59.13.76:2709/c/
w='2F117F75589EC2321B4054591AAC150E';
#uac='fFVzZXItQWdlbnQ9c3RhZ2VmcmlnaHQmc3RyZWFtdHlwZT1ITFMmc2V0cmVzb2x2ZWQ9dHJ1ZQ=='
#|User-Agent=stagefright&streamtype=HLS&setresolved=true
uac='fFVzZXItQWdlbnQ9c3RhZ2VmcmlnaHQ='
#|User-Agent=stagefright
#uac='fFVzZXItQWdlbnQ9c3RhZ2VmcmlnaHQmYXV0aD0mc3RyZWFtdHlwZT1ITFMmcHJveHk9Tm9uZSZzaW1wbGVkb3dubG9hZGVyPUZhbHNl'
#|User-Agent=stagefright&streamtype=HLS&setresolved=true
#|User-Agent=stagefright&auth=&streamtype=HLS&proxy=None&simpledownloader=False
cook='ZG9tYWluPWQuZG9pcHR2LmNvbTsgbWFjPTAwOjFBOjc5OjAwOjMyOkFCOyBzdGJfbGFuZz1ydTsgdGltZXpvbmU9RXVyb3BlL0tpZXY='
#domain=d.doiptv.com; mac=00:1A:79:00:32:AB; stb_lang=ru; timezone=Europe/Kiev
#cook='bWFjPTAwOjFBOjc5OjAwOjMyOkFCOyBzdGJfbGFuZz1ydTsgdGltZXpvbmU9RXVyb3BlL0tpZXY='
#mac=00:1A:79:00:32:AB; stb_lang=ru; timezone=Europe/Kiev
cook2='Q29va2llOiBtYWM9MDAlM0ExQSUzQTc5JTNBMDAlM0EzMiUzQUFCOyBzdGJfbGFuZz1ydTsgdGltZXpvbmU9RXVyb3BlJTJGS2lldg==';
#Cookie: mac=00%3A1A%3A79%3A00%3A32%3AAB; stb_lang=ru; timezone=Europe%2FKiev
j='aHR0cDovLzEyNy4wLjAuMTo1NTMzMy91c2VfcHJveHlfZm9yX2NodW5rcz1UcnVlJm1heGJpdHJhdGU9MCZ1cmw9';
#'http://127.0.0.1:55333/use_proxy_for_chunks=True&maxbitrate=0&url='
'''
_ym26609445_lsid=1132762393953; _ym26609445_reqNum=26; _ym_retryReqs={}
_ym26609445_lsid=1132762393953; _ym26609445_reqNum=27; _ym_retryReqs={}
_ym26609445_lsid=1132762393953; _ym26609445_reqNum=28; _ym_retryReqs={}
mac=00:1A:79:00:32:AB; stb_lang=ru; timezone=Europe/Kiev; _ym26609445_lsid=1132762393953; _ym26609445_reqNum=28; _ym_retryReqs={}
'''
def stalker0(params):
 #url=q.decode('base64')+'?type=stb&action=handshake&JsHttpRequest=1-xml&|X-User-Agent=Model: MAG250; Link: Ethernet,WiFi'
 url=q.decode('base64')+'?type=stb&action=handshake&JsHttpRequest=1-xml&|X-User-Agent=Model: MAG254; Link: Ethernet,WiFi'
 request_headers=[];
 #request_headers.append(["User-Agent","Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)"])
 request_headers.append(["User-Agent","Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3"])
 #request_headers.append(["User-Agent","MAG 250"])
 request_headers.append(['Cookie',cook.decode('base64')])
 body,response_headers=plugintools.read_body_and_headers(url, headers=request_headers);
 print '111111111111111111111',body,response_headers
 r='"token":"([^"]+)';w=plugintools.find_single_match(body,r);
 #url=q.decode('base64')+'?type=stb&action=get_profile&hd=1&ver=ImageDescription:%200.2.16-250;%20ImageDate:%2018%20Mar%202013%2019:56:53%20GMT+0200;%20PORTAL%20version:%2??04.9.6;%20API%20Version:%20JS%20API%20version:%20328;%20STB%20API%20version:%20?1?34;%20Player%20Engine%20version:%200x560&num_banks=1&sn=7384950694837&stb_type=MAG250&image_version=216&auth_second_step=0&hw_version=1.7-BD-00&not_valid_token=0&JsHttpRequest=1-xml&|Authorization=Bearer%20'+w
 url=q.decode('base64')+'?type=stb&action=get_profile&hd=1&ver=ImageDescription: 0.2.18-r10-pub-254; ImageDate: Wed Jan 14 13:35:06 EET 2015; PORTAL version: Latest; API Version: JS API version: 331; STB API version: 140; Player Engine version: 0x570&num_banks=2&sn=122014J031710&stb_type=MAG254&image_version=218&device_id=7AF9F1803BBA15703DC6B8EA08BD7547276F395F EF08DF726CC0C846923386BB& device_id2=7B515D9CB2A7151F12A02E716C0D00701933141 9866238177DD38980E7BAC44C&signature=9940DD9041A849CD82237D1FD9927F0E82D29F2B BC724E6E56678099FA4139AD&auth_second_step=0&hw_version=2.6-IB-00&not_valid_token=0&JsHttpRequest=1-xml&|Authorization=Bearer '+w;print url
 body,headers=plugintools.read_body_and_headers(url, headers=request_headers);
 print '2222222222222222222',body,response_headers
 url=q.decode('base64')+'?type=itv&action=get_all_channels&JsHttpRequest=1-xml&|Authorization=Bearer '+w
 body,headers=plugintools.read_body_and_headers(url, headers=request_headers);
 #print '33333333333333333333',body,response_headers
 datos=json.loads(body);tvg=[];
 for grup in datos['js']['data']:
   if 'tv_genre_id' in grup: tv_genre_id = grup['tv_genre_id']
   else: tv_genre_id='Sin Genero';
   #if tv_genre_id=='6':tv_genre_id='Sport'
   if 'name' in grup: name=grup['name']
   if 'cmd' in grup: url=grup['cmd'];print url
   plugintools.add_item(action='w1',title=name,url=url,thumbnail='',fanart='',isPlayable=True,folder=False)
   tvg.append(tv_genre_id)
 tvg=list(set(tvg));tvg=sorted(tvg);
 for x in tvg:
   title="[COLOR=green]"+str(x)+"[/COLOR]";
   plugintools.add_item(action='zet',title=title,url=str(x),thumbnail='',fanart='',isPlayable=False,folder=True)
   
def w1(params):
 url=q.decode('base64')+'?type=stb&action=handshake&JsHttpRequest=1-xml&|X-User-Agent=Model: MAG250; Link: Ethernet,WiFi'
 request_headers=[];
 request_headers.append(["User-Agent","Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)"])
 request_headers.append(['Cookie',cook.decode('base64')])
 body,response_headers=plugintools.read_body_and_headers(url, headers=request_headers);
 r='"token":"([^"]+)';w=plugintools.find_single_match(body,r);
 url=q.decode('base64')+'?type=stb&action=get_profile&hd=1&ver=ImageDescription:%200.2.16-250;%20ImageDate:%2018%20Mar%202013%2019:56:53%20GMT+0200;%20PORTAL%20version:%2??04.9.6;%20API%20Version:%20JS%20API%20version:%20328;%20STB%20API%20version:%20?1?34;%20Player%20Engine%20version:%200x560&num_banks=1&sn=7384950694837&stb_type=MAG250&image_version=216&auth_second_step=0&hw_version=1.7-BD-00&not_valid_token=0&JsHttpRequest=1-xml&|Authorization=Bearer%20'+w
 body,headers=plugintools.read_body_and_headers(url, headers=request_headers);
 url=q.decode('base64')+'?type=itv&action=get_all_channels&JsHttpRequest=1-xml&|Authorization=Bearer '+w
 body,headers=plugintools.read_body_and_headers(url, headers=request_headers);
 datos=json.loads(body);
 grp=params.get('url');
 for grup in datos['js']['data']:
  if 'tv_genre_id' in grup: tvg=grup['tv_genre_id']
  if tvg==grp:
   print grp['name'],grp['cmd'],grp['tv_genre_id']
   if 'name' in grup: name = grup['name'].encode('utf8').upper();
   if 'cmd' in grup:
    cmd = grup['cmd'].encode('utf8').replace('\/','/');print cmd
    r='(http.*)';cmd=plugintools.find_single_match(cmd,r);cmd=cmd.replace('4388/','4388/'+w);
    cmd=urllib.quote_plus(cmd+uac.decode('base64')).replace('\\\\/','/');
   if 'status' in grup: status = grup['status']
   if 'hd' in grup: hd = grup['hd']
   if 'xmltv_id' in grup: xmltv_id = grup['xmltv_id']
   if 'cur_playing' in grup: cur_playing = grup['cur_playing'].encode('utf8')
   if str(cur_playing)=='[No channel info]': epg='';
   else: epg="\n[COLOR=ff00ff7f]"+urllib.unquote_plus(replac(cur_playing))+"[/COLOR]"
   if str(status)=='1': col='green';
   else: col='red';
   if str(hd)=='0': qual='SD';
   else: qual='[COLOR=red]HD[/COLOR]';
   tagss='[COLOR=yellow] ('+str(qual)+')[/COLOR][COLOR=cyan] '+str(xmltv_id)+'[/COLOR] ';
   title="[COLOR="+col+"]"+str(name)+"[/COLOR]"+tagss+str(epg);
   #plugintools.add_item(action='',title=title,url=cmd.decode('base64'),thumbnail='',fanart='',isPlayable=True,folder=False)
   plugintools.add_item(action='zet',title=title,url=cmd,thumbnail='',fanart='',isPlayable=True,folder=False);
 
def zet(params):
 authurl=urllib.unquote_plus(params.get("url"));print authurl;sys.exit()
 plugintools.play_resolved_url(params['url'])
 url='plugin://plugin.video.f4mTester/?url='+authurl+'&mode=play&streamtype=HLS&setResolved=true'
 xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
 #xbmc.Player().play(authurl)
 
def replac(title):
  title = title.replace("&#351;","s");
  title = title.replace("&#353;","s");
  title = title.replace("&#263;","c");
  title = title.replace("&#268;","C");
  title = title.replace("&#269;","c");
  title = title.replace("\xe2","a");
  title = title.replace("\xaa","S");
  title = title.replace("\xa0","S");
  title = title.replace("\xba","s");
  title = title.replace("\xe2","i");#i din i
  title = title.replace("\xee","i");#i din i
  title = title.replace("\xce","I");#i din i
  title = title.replace("\x80","Q");
  title = title.replace("\x93","Y");
  title = title.replace("\x99","W");
  title = title.replace("\xc3","t");
  title = title.replace("\xe0","f");
  title = title.replace("\xfc","u");
  title = title.replace("\xf3","o");
  title = title.replace("\xfe","t");
  title = title.replace("\xe3","a");
  title = title.replace("\xdb","s");
  title = title.replace("\xbd","1/2");
  title = title.replace("\x15f","s");#U+211C (8476)
  #print title.encode('utf-8');#enable for debug!!!
  return title