# -*- coding: utf-8 -*-
#------------------------------------------------------------
# URL Tester on Movie Ultra 7K
# Version 0.1 (01.12.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)

from __main__ import *

import os
import sys
import urllib
import urllib2
import re
import shutil
import zipfile
import time

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import re,urllib,urllib2,sys
import plugintools,ioncube

from __main__ import *

thumbnail = 'http://static.myce.com/images_posts/2011/04/kickasstorrents-logo.jpg'
#fanart = 'http://i.imgur.com/LaeHXnR.png'
fanart = 'https://yuq.me/users/19/529/lcqO6hj0XK.png'

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

def url_tester(params):
    url_test = plugintools.keyboard_input(texto, "Probar URL!")
    params["plot"]=url_test
    url_test = url_test.lower()
    if url_test == "":
        errormsg = plugintools.message("Movie Ultra 7K","Por favor, introduzca el canal a buscar")        
    else:
        plugintools.log('[%s %s] Probando URL... %s' % (addonName, addonVersion, repr(params)))
        url_test = url_test.lower().strip()
        params["url"]=url_test
        server_rtmp(url)
        plugintools.play_resolved_url(url_test)  

