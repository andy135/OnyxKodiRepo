from __main__ import *
#url=xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ciptv/playlists/tstone.xml', ''))
'''
http://tv.inetehno.md/

http://109.200.20.26:8981/FHDDolce/Sports1/index.m3u8

183.red-2-136-186.dynamicip.rima-tde.net
ac88bab7.ipt.aol.com
http://2.136.186.183:4022/udp/239.0.0.32:8208

tvmia
usuario: 202058
clave : FWGIKEAA

http://tv.vera.com.uy/canal/6038
http://www.sintelevisor.com/int/index.html#
'''

def test2(params):
 #url='plugin://plugin.video.f4mTester/?url=http%3A%2F%2Fcctv-lh.akamaihd.net%2Fz%2Flacasa_live%40125114%2Fmanifest.f4m%3Fhdcore%3D3.5.0'
 url='plugin://plugin.video.f4mTester/?url='+urllib.quote_plus('http://cctv-lh.akamaihd.net/z/lacasa_live@125114/manifest.f4m?hdcore=3.5.0')
 #runPlugin('plugin://plugin.video.f4mTester/?url='+urllib.quote_plus('http://cctv-lh.akamaihd.net/z/lacasa_live@125114/manifest.f4m?hdcore=3.5.0'))
def test3(params): url='http://brightcove03-f.akamaihd.net/HOGARUTIL_1_1100@117573?videoId=2518851062001/HOGARUTIL_1_1100@117573.flv'
def test6(params):
 url='rtmp://5.135.137.172/live swfUrl=http://www.mipsplayer.com/content/scripts/fplayer.swf ccommand=gaolVanusPobeleVoKosata;TRUE;TRUE pageUrl=http://cinestrenostv.tv/canales/emision/plus1.html conn=S:OK live=1 playpath=streamhd?id=224096';play(url)#http://i.imgur.com/H1rCr9Z.png
def test7(params):
 url='http://vdmedia_1.plus.es/topdigitalplus/20153/9/c51481aa2a1d5180d2deb5f28a12e621_2096.mp4';play_resolved_url(url)#http://i.imgur.com/H1rCr9Z.png
def test1(params): url='plugin://plugin.video.live.streamspro/?url='+url
def test4(params):
 url='rtmp://5.135.137.172/live playpath=asdf3asdfasdfasss?id=224082 swfUrl=http://www.mipsplayer.com/content/scripts/fplayer.swf ccommand=gaolVanusPobeleVoKosata;TRUE;TRUE pageUrl=http://www.mipsplayer.com/embedplayer/asdf3asdfasdfasss/1/650/450';play(url)
def test5(params):
 url='plugin://plugin.video.f4mTester/?url='+urllib.quote_plus('http://162.244.81.252:1935/Test/foot0live/manifest.f4m')
 #url='http://127.0.0.1:55333/use_proxy_for_chunks=True&maxbitrate=0&url='+urllib.quote_plus('http://hds_live_cpc_aka-lh.akamaihd.net/z/cpc_hds@182615/manifest.f4m?hdcore=3.5.0')+'&auth=&streamtype=HDS&proxy=None&simpledownloader=False'
 #play_resolved_url(url);sys.exit();
 #xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
 play(url)
 
def test8(params):
 url='plugin://plugin.video.f4mTester/?url='+urllib.quote_plus('http://flive.cdn.antel.net.uy/ams/live.site/auth_0_6ktg9sik/hds/auth_0_6ktg9sik.f4m?vxttoken=cGF0aFVSST0lMkZhbXMlMkZsaXZlLnNpdGUlMkZhdXRoXzBfNmt0ZzlzaWslMkZoZHMlMkYlMkEmcGF0aFVSST0lMkZoZHMtbGl2ZSUyRmxpdmVwa2dyJTJGYXV0aF8wXzZrdGc5c2lrJTJGbGl2ZWV2ZW50JTJGJTJBJnBhdGhVUkk9JTJGaGRzLWxpdmUlMkZzdHJlYW1zJTJGbGl2ZXBrZ3IlMkZldmVudHMlMkZhdXRoXzBfNmt0ZzlzaWslMkZsaXZlZXZlbnQlMkYlMkEmZXhwaXJ5PTE0MjYzMTcyMzgmcmFuZG9tPTU1MDM4YjU2MDNlMTgsNjZhYTNlZjhkYzZjN2EyNDdhMTdjMDE3MDdlM2ZjYjNiY2YyOWYxMzg2NTdmNzI3Njk5M2Q0NjFhMTIxZWQ0ZQ==')
 
def test9(params):
 #url='rtp://83.60.102.177:4022/udp/239.0.0.5:8208'
 url='magnet%3A%3Fxt%3Durn%3Abtih%3A92F096D5B549284C0698823F7BF7C3C794A24E0B%26dn%3DMessi%20Film%20(2014)%20720p%20HD-Rip%20Eng-Sub%20H.264%20(x264)%20%5BEncoded%20Raiyanlabib%5D%26tr%3Dhttp%3A%2F%2Ftracker.aletorrenty.pl%3A2710%2Fannounce%26tr%3Dhttp%3A%2F%2Fexodus.desync.com%3A6969%2Fannounce%26tr%3Dhttp%3A%2F%2Fbttracker.crunchbanglinux.org%3A6969%2Fannounce%26tr%3Dhttp%3A%2F%2Ftorrent.gresille.org%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce%26tr%3Dudp%3A%2F%2Fopen.demonii.com%3A1337%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.glotorrents.com%3A6969%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.istole.it%3A80%2Fannounce%26tr%3Dhttp%3A%2F%2F94.228.192.98%2Fannounce%26tr%3Dhttp%3A%2F%2Fexodus.desync.com%2Fannounce%26tr%3Dudp%3A%2F%2F9.rarbg.com%3A2710%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.prq.to%2Fannounce'
 play('plugin://plugin.video.kmediatorrent/play/'+url)
 #url='rtmp://antena3fms35geobloqueolivefs.fplive.net:1935/antena3fms35geobloqueolive-live/stream-eventos2geo_1'
 #play(url)
def test0(params):
 url='plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=http://verdirectotv.com/tv/documentales/discovery.html%26referer=http://verdirectotv.com/';xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
'''
import playerw
from playerw import *
from F4mProxy import f4mProxyHelper
player=f4mProxyHelper()
import playerw
from playerw import *

def test0(params):
 auth='7C00368702FC8047C332689BC1E3C573'
 termi='&auth=&streamtype=HLS&proxy=None&simpledownloader=False'
 url='plugin://plugin.video.f4mTester/?url=http%3A%2F%2Fip.doiptv.com%2F'+auth+'%2Fcs_canal_1%2F%7CUser-Agent%3Dstagefright'+termi
 #xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
 playerw.play(url)
 #play(url, windowed)
 #urt='http://127.0.0.1:55333/use_proxy_for_chunks=True&maxbitrate=0&url=http%3A%2F%2Fip.doiptv.com%2F4388%2F18F5A1051D13C860CE8133789AEE8B77%2Fcs_canal_1%2F%7CUser-Agent%3Dstagefright'+termi
 #plugintools.direct_play(urt);
 #urt='rtmp://stream.taksimbilisim.com/wtc/ playpath=bant1 swfUrl=http://smartvbla.zz.mu/tv/player.swf live=1 pageUrl=http://smartvbla.zz.mu/tv/documentales/world-travel-chan/'
 #plugintools.play_resolved_url(urt);
 url='plugin://plugin.video.live.streamspro/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Furl%3D%24doregex%5Bget-urlencoded%5D%26streamtype%3DHLS%26setresolved%3Dtrue&mode=17&regexs=%7Bu%27get-Profile%27%3A%20%7B%27setcookie%27%3A%20u%27mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Dstb%26action%3Dget_profile%26hd%3D1%26ver%3DImageDescription%3A%25200.2.16-250%3B%2520ImageDate%3A%252018%2520Mar%25202013%252019%3A56%3A53%2520GMT%2B0200%3B%2520PORTAL%2520version%3A%252%3F%3F04.9.6%3B%2520API%2520Version%3A%2520JS%2520API%2520version%3A%2520328%3B%2520STB%2520API%2520version%3A%2520%3F1%3F34%3B%2520Player%2520Engine%2520version%3A%25200x560%26num_banks%3D1%26sn%3D7384950694837%26stb_type%3DMAG250%26image_version%3D216%26auth_second_step%3D0%26hw_version%3D1.7-BD-00%26not_valid_token%3D0%26JsHttpRequest%3D1-xml%26%7CAuthorization%3DBearer%20%24doregex%5Bget-auth%5D%27%2C%20%27expre%27%3A%20%27%27%7D%2C%20u%27get-url%27%3A%20%7B%27setcookie%27%3A%20u%27mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Ditv%26action%3Dget_all_channels%26JsHttpRequest%3D1-xml%26%7CAuthorization%3DBearer%20%24doregex%5Bget-auth%5D%24doregex%5Bget-Profile%5D%27%2C%20%27expre%27%3A%20u%27%22Canal%201%22.%2A%3F%28http.%2A%3F%29%22%27%7D%2C%20u%27get-urlencoded%27%3A%20%7B%27page%27%3A%20None%2C%20%27expre%27%3A%20u%22%24pyFunction%3Aurllib.quote_plus%28%27%24doregex%5Bget-url%5D%7CUser-Agent%3Dstagefright%27.replace%28%27%5C%5C%5C%5C/%27%2C%27/%27%29%29%22%7D%2C%20u%27get-auth%27%3A%20%7B%27setcookie%27%3A%20u%27Cookie%3A%20mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Dstb%26action%3Dhandshake%26JsHttpRequest%3D1-xml%26%7CX-User-Agent%3DModel%3A%20MAG250%3B%20Link%3A%20Ethernet%2CWiFi%27%2C%20%27expre%27%3A%20u%27token%22%3A%22%28.%2A%3F%29%22%27%7D%7D'
 xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
 #url='plugin://plugin.video.live.streams/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Furl%3D%24doregex%5Bget-urlencoded%5D%26streamtype%3DHLS%26setresolved%3Dtrue&mode=17&regexs=%7Bu%27get-Profile%27%3A%20%7B%27setcookie%27%3A%20u%27mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Dstb%26action%3Dget_profile%26hd%3D1%26ver%3DImageDescription%3A%25200.2.16-250%3B%2520ImageDate%3A%252018%2520Mar%25202013%252019%3A56%3A53%2520GMT%2B0200%3B%2520PORTAL%2520version%3A%252%3F%3F04.9.6%3B%2520API%2520Version%3A%2520JS%2520API%2520version%3A%2520328%3B%2520STB%2520API%2520version%3A%2520%3F1%3F34%3B%2520Player%2520Engine%2520version%3A%25200x560%26num_banks%3D1%26sn%3D7384950694837%26stb_type%3DMAG250%26image_version%3D216%26auth_second_step%3D0%26hw_version%3D1.7-BD-00%26not_valid_token%3D0%26JsHttpRequest%3D1-xml%26%7CAuthorization%3DBearer%20%24doregex%5Bget-auth%5D%27%2C%20%27expre%27%3A%20%27%27%7D%2C%20u%27get-url%27%3A%20%7B%27setcookie%27%3A%20u%27mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Ditv%26action%3Dget_all_channels%26JsHttpRequest%3D1-xml%26%7CAuthorization%3DBearer%20%24doregex%5Bget-auth%5D%24doregex%5Bget-Profile%5D%27%2C%20%27expre%27%3A%20u%27%22Canal%201%22.%2A%3F%28http.%2A%3F%29%22%27%7D%2C%20u%27get-urlencoded%27%3A%20%7B%27page%27%3A%20None%2C%20%27expre%27%3A%20u%22%24pyFunction%3Aurllib.quote_plus%28%27%24doregex%5Bget-url%5D%7CUser-Agent%3Dstagefright%27.replace%28%27%5C%5C%5C%5C/%27%2C%27/%27%29%29%22%7D%2C%20u%27get-auth%27%3A%20%7B%27setcookie%27%3A%20u%27Cookie%3A%20mac%3D00%253A1A%253A79%253A00%253A32%253AAB%3B%20stb_lang%3Dru%3B%20timezone%3DEurope%252FKiev%27%2C%20%27page%27%3A%20u%27https%3A//d.doiptv.com/stalker_portal/server/load.php%3Ftype%3Dstb%26action%3Dhandshake%26JsHttpRequest%3D1-xml%26%7CX-User-Agent%3DModel%3A%20MAG250%3B%20Link%3A%20Ethernet%2CWiFi%27%2C%20%27expre%27%3A%20u%27token%22%3A%22%28.%2A%3F%29%22%27%7D%7D'
 #print urllib.unquote_plus(url)
 url='http://127.0.0.1:55333/use_proxy_for_chunks=True&maxbitrate=0&url=http%3A%2F%2Fip.doiptv.com%2F'+auth+'%2Fcs_canal_1%2F%7CUser-Agent%3Dstagefright&auth=&streamtype=HLS&proxy=None&simpledownloader=False'
 #xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
 xbmc.sleep(500)
 if not xbmc.Player().isPlaying():
  print '******USING play_resolved_url*******'
  plugintools.play_resolved_url(url);
  xbmc.sleep(500)
  if not xbmc.Player().isPlaying():
   print '******USING direct_play*******'
   plugintools.direct_play(url);
 #plugintools.direct_play('http://brightcove03-f.akamaihd.net/HOGARUTIL_1_1100@117573');
 #plugintools.add_item(action="",title='TestExternal',url='http://brightcove03-f.akamaihd.net/HOGARUTIL_1_1100@117573',thumbnail="",fanart="",isPlayable=True,folder=False)
 
'''