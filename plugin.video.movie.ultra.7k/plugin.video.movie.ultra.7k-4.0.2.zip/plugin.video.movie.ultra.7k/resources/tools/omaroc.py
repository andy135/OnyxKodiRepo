# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Movie Ultra 7K parser de mebuscan.net
# Version 0.1 (17.10.2014)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)


import os
import sys
import urllib
import urllib2
import re
import shutil
import zipfile

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools


thumbnail = 'https://lh5.ggpht.com/7-5WB_Lc3mOuEB6eIC8ilf3tnAScxk_IRuCheIRPFyL_pnZeEgFb33HTfE1w4I5NlaA=w300'
fanart = 'http://www.adslzone.net/app/uploads/2015/04/apertura-bein.jpg'
multisport = 'http://www.diocesi.torino.it/diocesitorino/allegati/55114/spor.jpg'

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")


def omaroc0(params):
    plugintools.log("[%s %s] Omaroc parser %s " % (addonName, addonVersion, repr(params)))
    
    plugintools.modo_vista("tvshows")
    datamovie = {}
    
    url_1 = 'http://omaroc.lixter.com/skymac.html'
    url_2 = 'http://omaroc.lixter.com/beinka.html'
    url_3 = 'http://omaroc.lixter.com/multiviewer9.html'
    
    plugintools.add_item(action="", title = '[B][I][COLOR lightyellow]O Maroc Sports Playlist[/B][/I][/COLOR]', url = "", thumbnail = thumbnail , fanart = fanart , folder = False, isPlayable = False)
    datamovie["Plot"]="Grupo de canales de Sky Sports en calidad SD"
    plugintools.add_item(action="omaroc_sky", title='[COLOR red][B]Sky[/B][/COLOR][COLOR blue] Sports UK[/COLOR]', url=url_1, thumbnail="https://pbs.twimg.com/profile_images/504278813644054528/lSkPHorY.png", fanart = 'http://tvnewsroom.org/wp-content/section-images/wallpapers/sshd.jpg' , info_labels = datamovie , folder = False, isPlayable = True)
    datamovie["Plot"]="Grupo de canales de beIN Sports"
    plugintools.add_item(action="omaroc_bein", title='[COLOR purple]be[B]IN[/B] Sports[/COLOR]', url=url_2, thumbnail="https://lh5.ggpht.com/7-5WB_Lc3mOuEB6eIC8ilf3tnAScxk_IRuCheIRPFyL_pnZeEgFb33HTfE1w4I5NlaA=w300", fanart = fanart , info_labels = datamovie , folder = False, isPlayable = True)
    datamovie["Plot"]=""
    plugintools.add_item(action="omaroc_multisport", title='[COLOR lightyellow]World Sports[/COLOR]', url=url_3, thumbnail="http://img.beckett.com/groupimages/sports/multisport.jpg", fanart = multisport , info_labels = datamovie , folder = False, isPlayable = True)
    datamovie["Plot"]=""    

         
     
       

def play_omaroc(params):
    plugintools.log("[%s %s] Omaroc parser %s " % (addonName, addonVersion, repr(params)))
    
    plugintools.modo_vista("tvshows")
    url = params.get("url")
    if url.startswith("rtmp") == True or url.startswith("rtmpe") == True:
        url = url + ' timeout=15'
    plugintools.play_resolved_url(url)

    

def omaroc_sky(params):
    plugintools.log("[%s %s] Omaroc: Sky channels %s " % (addonName, addonVersion, repr(params)))

    plugintools.modo_vista("tvshows")
    datamovie = {}    

    url = params.get("url")    
    
    data = plugintools.read(url)
    canales = []
    urls = []

    bloque = plugintools.find_single_match(data, '<br><script>(.*?)</script>')
    event = plugintools.find_multiple_matches(bloque, 'file:  "(.*?)},{')
    for entry in event:
        url_event = plugintools.find_single_match(entry, '([^"]+)')
        title_event = plugintools.find_single_match(entry, 'title: "([^"]+)')
        #thumb_event = plugintools.find_single_match(entry, 'image: "([^"]+)')
        title_event = title_event.replace("Sky", "[COLOR red][B]Sky[/B][/COLOR]")
        canales.append(title_event)
        urls.append(url_event)
        #plugintools.log("url_event= "+url_event)
        #plugintools.log("title_event= "+title_event)
        #plugintools.log("thumb_event= "+thumb_event)
        #if thumb_event == "": thumb_event = thumbnail
        #plugintools.add_item(action="play_omaroc", title=title_event, url=url_event, thumbnail=thumb_event, fanart = fanart , info_labels = datamovie , folder = False, isPlayable = True)

    try:
        seleccion = plugintools.selector(canales, "Sky Sports UK")
        url = urls[seleccion]
        if url.startswith("rtmp") == True or url.startswith("rtmpe") == True:
            url = url + ' timeout=15'
        plugintools.play_resolved_url(url)

    except KeyboardInterrupt: pass;
    except IndexError: raise;
    except: pass


def omaroc_bein(params):
    plugintools.log("[%s %s] Omaroc: beIN channels %s " % (addonName, addonVersion, repr(params)))

    plugintools.modo_vista("tvshows")
    datamovie = {}    

    url = params.get("url")

    data = plugintools.read(url)
    canales = []
    urls = []
    
    event = plugintools.find_multiple_matches(data, '<button(.*?)/button>')
    for entry in event:
        plugintools.log("entry= "+entry)
        url_event = plugintools.find_single_match(entry, "Video(.*?)class")
        url_event = url_event.replace("'", "").replace('"', "").replace(")", "").replace("(", "").strip()
        title_event = plugintools.find_single_match(entry, '>(.*?)<')
        title_event = title_event.replace("beIN", "[COLOR purple]be[B]IN[/B][/COLOR]")
        canales.append(title_event)
        urls.append(url_event)        
        #plugintools.log("url_event= "+url_event)
        #plugintools.log("title_event= "+title_event)
        #plugintools.add_item(action="play_omaroc", title=title_event, url=url_event, thumbnail=thumbnail, fanart = fanart , info_labels = datamovie , folder = False, isPlayable = True)
        
    
    try:
        seleccion = plugintools.selector(canales, "beIN Sports")
        url = urls[seleccion]
        if url.startswith("rtmp") == True or url.startswith("rtmpe") == True:
            url = url + ' timeout=15'
        plugintools.play_resolved_url(url)
        plugintools.modo_vista("tvshows")

    except KeyboardInterrupt: pass;
    except IndexError: raise;
    except: pass 



def omaroc_multisport(params):
    plugintools.log("[%s %s] Omaroc: Multisport channels %s " % (addonName, addonVersion, repr(params)))

    plugintools.modo_vista("tvshows")
    datamovie = {}    

    url = params.get("url")

    data = plugintools.read(url)
    canales = []
    urls = []
    
    bloque = plugintools.find_single_match(data, '<br>(.*?)</script>')
    event = plugintools.find_multiple_matches(bloque, '{(.*?)}')
    for entry in event:
        plugintools.log("entry= "+entry)
        url_event = plugintools.find_single_match(entry, 'file:"([^"]+)')
        plugintools.log("url_event= "+url_event)
        if url_event == "":
            url_event = plugintools.find_single_match(entry, 'file: "([^"]+)')            
        title_event = plugintools.find_single_match(entry, 'title:"([^"]+)')
        #thumb_event = plugintools.find_single_match(entry, 'image:"([^"]+)')
        if title_event == "":
            title_event = plugintools.find_single_match(entry, 'title: "([^"]+)')
        canales.append(title_event)
        urls.append(url_event) 

    try:
        seleccion = plugintools.selector(canales, "beIN Sports")
        url = urls[seleccion]
        if url.startswith("rtmp") == True or url.startswith("rtmpe") == True:
            url = url + ' timeout=15'
        plugintools.play_resolved_url(url)
        plugintools.modo_vista("tvshows")

    except KeyboardInterrupt: pass;
    except IndexError: raise;
    except: pass             
