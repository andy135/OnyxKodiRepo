# -*- coding: utf-8 -*-
#--------------------------------------------------------
#  Movie Ultra 7K
# Version 0.0.1 (26.10.2014)
#--------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
#--------------------------------------------------------
#
#http://verdirectotv.com/carrusel/tv.html
#http://cinestrenostv.tv/carrusel/tv.html
#http://tvenganchado.com/parrilla/
#http://juanintv.net
#http://channel.verlatelegratis.net/canalespropios.php
#http://streamingfreetv.net/
#

from __main__ import *
burl='http://streamingfreetv.net/'

def sft0(params):
 mssg='buscando programas...';timp=1000;exec(dlg);
 plugintools.add_item(title=params['title'],thumbnail=params['thumbnail'],fanart=params['thumbnail'],isPlayable=False,folder=False);
 plugintools.add_item(title='Orden alfabetico',action='sft1',thumbnail=params['thumbnail'],fanart=params['thumbnail'],isPlayable=False,folder=True);
 plugintools.add_item(title='Categorias',action='sft2',thumbnail=params['thumbnail'],fanart=params['thumbnail'],isPlayable=False,folder=True);
 
def sft1(params):
 body,jar=plugintools.read_body_and_headers(burl);r='<ul\sclass="abc">(.*?)<\/ul>';w=plugintools.find_single_match(body,r);
 r='href="([^"]+)">([^<]+)';w=plugintools.find_multiple_matches(w,r);
 for x in w: plugintools.add_item(title=x[1],action='sft11',url=x[0],thumbnail=params['thumbnail'],isPlayable=False,folder=True); 
 
def sft11(params):
 url='http://pontucanal.net/player.php?c='+params['url']+'&w=650&h=400';mssg='buscando enlaces...';timp=1000;exec(dlg);body,jar=plugintools.read_body_and_headers(url);r='<iframe.*?src="([^\'"]*).*?<\/iframe>';w=plugintools.find_multiple_matches(body,r);w=w[1:-1]
 body=curl_frame(w[0],url,'');print body
		
def sft2(params):
 body,jar=plugintools.read_body_and_headers(burl);r='<ul\sid="menu-mw?enu\d{1}"\sclass="ge">(.*?)<\/ul>';w=plugintools.find_multiple_matches(body,r);c={};
 for x in w: 
  r='href="([^"]+)">([^<]+)';y=plugintools.find_multiple_matches(x,r);
  for i in y: c.update({i[1]:i[0]});
 c={k:v for k,v in c.items() if k != 'PROGRAMACION'}
 try: from collections import OrderedDict;c=OrderedDict(sorted(c.items()));
 except: c=dict(sorted(c.items()));
 for k,v in c.items(): plugintools.add_item(title=k,action='sft21',url=v,thumbnail=params['thumbnail'],isPlayable=False,folder=True);
 
def sft21(params):
 body=curl_frame(params['url'],burl,'');r='<div\sclass="estre">(.*?)<div\sclass="paginacion">';w=plugintools.find_single_match(body,r);
 r='(href|title|src)="([^"]+)';w=plugintools.find_multiple_matches(w,r);w=[x[1].replace(' ()','') for x in w];q=[];
 for x in w:
  if x not in q: q.append(x);
 for i,j in enumerate(q):
  if i%3==0: plugintools.add_item(title=q[i+1].upper(),action='sft22',url=q[i],thumbnail=q[i+2],fanart=params['thumbnail'],isPlayable=True,folder=False);
  
def sft22(params):
 body=curl_frame(params['url'],burl,'');r='<iframe\sid="list"\ssrc="([^"]+)';w=plugintools.find_single_match(body,r);
 body=curl_frame(w,params['url'],'');
 try:
  r='<iframe\sid="list"\ssrc="([^"]+)';w=plugintools.find_single_match(body,r);body=curl_frame(w,params['url'],'');
  if body.find('1broadcastlive.com'):
   try: print '1broadcastlive';broadcastlive(w,params['url'],'')
   except: pass;#print 'streamingfreetv';streamingfreetv(w,params['url'],'')
  else: eval(nolink);print 'UNKNOWN';
 except: r='<iframe.*?src="([^"]+)';w=plugintools.find_single_match(body,r);body=curl_frame(w,params['url'],'');
 try:
  r='(width|height|channel|src)=\'?([^,\']+)';w=plugintools.find_multiple_matches(body,r);
  if w[3][1].find('privado.streamingfreetv.net'):
   try: print 'streamingfreetv';w='http://privado.streamingfreetv.net/embed/embed.php?channel='+w[2][1]+'&w='+w[0][1]+'&h='+w[1][1];streamingfreetv(w,params['url'],'')
   except: pass;
  else: eval(nolink);print 'UNKNOWN';
 except: eval(nolink);pass
 
def curl_frame(url,ref,body):
 request_headers=[];request_headers.append(["User-Agent","Chrome/26.0.1410.65 Safari/537.31","Referer",ref])
 body,response_headers=plugintools.read_body_and_headers(url,headers=request_headers);print response_headers
 return body