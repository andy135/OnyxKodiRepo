![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.youtube/icon.png)
# **Links:**

* [YouTube](http://www.youtube.com)
* [EndPoints - Videos](https://github.com/bromix/plugin.video.youtube/wiki/EndPoints#videos)
* [EndPoints - Playlist](https://github.com/bromix/plugin.video.youtube/wiki/EndPoints#playlists)
* [EndPoints - Channels](https://github.com/bromix/plugin.video.youtube/wiki/EndPoints#channels)
* [Missing or not supported](https://github.com/bromix/plugin.video.youtube/wiki/Missing-or-Broken)
* [Support thread](http://forum.kodi.tv/showthread.php?tid=200735)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) [![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/flattr-badge-large.png)](http://flattr.com/thing/4196324) 

# **Images:**
![](http://i.imgur.com/W5UEby8.png)
![](http://i.imgur.com/rfqpIYC.png)
![](http://i.imgur.com/hoIuZ1K.png)
